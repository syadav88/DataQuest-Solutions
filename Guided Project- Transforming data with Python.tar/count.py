import read
df = read.load_data()

import pandas as pd

headlines = df['headline']
print(headlines.head())

long_string = ""
for hl in headlines:
    long_string = long_string + str(hl) + " "
    
from collections import Counter

print(Counter(long_string.lower().split()).most_common(100))