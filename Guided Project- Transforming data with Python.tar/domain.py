import read
df = read.load_data()

import pandas as pd

url = df['url']
domains = url.value_counts()
top_100 = domains[:100]

for name, row in top_100.items():
    print("{0}: {1}".format(name, row))
