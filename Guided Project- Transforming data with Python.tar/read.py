if __name__ == "__main__":
        print("Welcome to a Python script")
def load_data():
    pass

    if __name__ == "__main__":
        # This will call load_data if you run the script from the command line.
        load_data()        
    return

import pandas as pd
from pandas import DataFrame
import csv

#file = pd.DataFrame(pd.read_csv("hn_stories.csv"))
#file.columns = ['submission_time', 'upvotes', 'url', 'headline']

def load_data():
    file = pd.DataFrame(pd.read_csv("hn_stories.csv"))
    file.columns = ['submission_time', 'upvotes', 'url', 'headline']
    return file



