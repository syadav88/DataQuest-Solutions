import dateutil as dt
import datetime
import read
import pandas as pd
from collections import Counter

df = read.load_data()
timestamp = df['submission_time']

'''for i in timestamp:
    time = dt.parser.parse(i).hour

print(time)'''

def time(time):
    return dt.parser.parse(time).hour

print(timestamp.apply(time).value_counts())