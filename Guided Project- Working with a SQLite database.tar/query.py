import sqlite3
conn = sqlite3.connect('factbook.db')


query1 = conn.cursor()
query1.execute('select population from facts order by population ASC limit 10;')
print(query1.fetchall())

conn.close(

